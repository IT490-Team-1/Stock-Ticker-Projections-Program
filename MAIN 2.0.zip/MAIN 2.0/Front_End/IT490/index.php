<?php 
session_start();
// Include configuration file  
require_once 'config.php'; 
if(isset($_SESSION["email"]) && $_SESSION["email"] != ""){
    header('location: home.php');
    exit();
}
if(!isset($_SESSION["reg_email"]) && $_SESSION["reg_email"] == ""){
    header('location: signup-user.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.materialdesignicons.com/4.8.95/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://js.stripe.com/v3/"></script>

    <title>Document</title>
</head>
<body>
<main class="d-flex align-items-center min-vh-100 py-3 py-md-0">
    <div class="container">
      <div class="card login-card">
        <div class="row no-gutters">
          <div class="col-md-5">
            <img src="https://web.njit.edu/~zaa4/5150.jpg" alt="login" class="login-card-img">
          </div>
          <div class="col-md-7">
            <div class="card-body">
              <div class="brand-wrapper">
                <img src="https://web.njit.edu/~zaa4/logo2.svg" alt="logo" class="logo">
              </div>
             
              <form class="test" action="payment.php" method="POST" id="paymentFrm">
                <div class="panel-heading">
                    
                    <!-- Plan Info -->
                    
                        <div class="form-group">
                        <label class="control-label" >Select Plan</label>
                        <select name="subscr_plan" id="subscr_plan" class="form-control">
                            <?php foreach($plans as $id=>$plan){ ?>
                                <option value="<?php echo $id; ?>"><?php echo $plan['name'].' [$'.$plan['price'].'/'.$plan['interval'].']'; ?></option>
                            <?php } ?>
                        </select>
                    </p>
                </div>
            </div>
                <div class="panel-body">
                    <!-- Display errors returned by createToken -->
                    <div id="paymentResponse"></div>
                    
                    <!-- Payment form -->
                    <div class="form-group">
                        <label  >NAME</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="Enter name" required="" autofocus="">
                    </div>
                    <div class="form-group">
                        <label>EMAIL</label>
                        <input type="email" name="email" id="email" class="form-control" placeholder="Enter email" required="">
                    </div>
                    <div class="form-group">
                        <label>CARD NUMBER</label>
                        <div id="card_number" class="form-control"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>EXPIRY DATE</label>
                                <div id="card_expiry" class="form-control"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>CVC CODE</label>
                                <div id="card_cvc" class="form-control"></div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="form-control2" id="payBtn">Submit Payment</button>
                </div>
            </form>

               
            </div>
          </div>
        </div>
      </div>
     
    </div>
  </main>
  
<script>
// Create an instance of the Stripe object
// Set your publishable API key
var stripe = Stripe('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');

// Create an instance of elements
var elements = stripe.elements();

var style = {
    base: {
        fontWeight: 400,
        fontFamily: 'Roboto, Open Sans, Segoe UI, sans-serif',
        fontSize: '16px',
        lineHeight: '1.4',
        color: '#555',
        backgroundColor: '#fff',
        '::placeholder': {
            color: '#888',
        },
    },
    invalid: {
        color: '#eb1c26',
    }
};

var cardElement = elements.create('cardNumber', {
    style: style
});
cardElement.mount('#card_number');

var exp = elements.create('cardExpiry', {
    'style': style
});
exp.mount('#card_expiry');

var cvc = elements.create('cardCvc', {
    'style': style
});
cvc.mount('#card_cvc');

// Validate input of the card elements
var resultContainer = document.getElementById('paymentResponse');
cardElement.addEventListener('change', function(event) {
    if (event.error) {
        resultContainer.innerHTML = '<p>'+event.error.message+'</p>';
    } else {
        resultContainer.innerHTML = '';
    }
});

// Get payment form element
var form = document.getElementById('paymentFrm');

// Create a token when the form is submitted.
form.addEventListener('submit', function(e) {
    e.preventDefault();
    createToken();
});

// Create single-use token to charge the user
function createToken() {
    stripe.createToken(cardElement).then(function(result) {
        if (result.error) {
            // Inform the user if there was an error
            resultContainer.innerHTML = '<p>'+result.error.message+'</p>';
        } else {
            // Send the token to your server
            stripeTokenHandler(result.token);
        }
    });
}

// Callback to handle the response from stripe
function stripeTokenHandler(token) {
    // Insert the token ID into the form so it gets submitted to the server
    var hiddenInput = document.createElement('input');
    hiddenInput.setAttribute('type', 'hidden');
    hiddenInput.setAttribute('name', 'stripeToken');
    hiddenInput.setAttribute('value', token.id);
    form.appendChild(hiddenInput);
	
    // Submit the form
    form.submit();
}
</script>
</body>
</html>