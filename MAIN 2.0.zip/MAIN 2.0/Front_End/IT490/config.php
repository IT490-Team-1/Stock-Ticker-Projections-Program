<?php 
// Subscription plans 
// Minimum amount is $0.50 US 
// Interval day, week, month or year 
$plans = array( 
    '1' => array( 
        'name' => 'Weekly Subscription', 
        'price' => 25, 
        'interval' => 'week' 
    ), 
    '2' => array( 
        'name' => 'Monthly Subscription', 
        'price' => 85, 
        'interval' => 'month' 
    ), 
    '3' => array( 
        'name' => 'Yearly Subscription', 
        'price' => 950, 
        'interval' => 'year' 
    ) 
); 
$currency = "USD";  
 
/* Stripe API configuration 
 * Remember to switch to your live publishable and secret key in production! 
 * See your keys here: https://dashboard.stripe.com/account/apikeys 
 */ 
define('STRIPE_API_KEY', 'sk_test_51IJ86WHufV9vgSs3JOSLmMBoy8oguC1KAgN0AaorxMQz85wDQGLfB2dxJx7BarFGL1wOAsQVrDLjUrHLKS4oJaAA00gike6YTt'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51IJ86WHufV9vgSs3BnQZK20mIOhD0Ny1nNWGIn0qptmsNqmgw8HdAQZYVUqpctCf9IKeXsx41nE1rQsqn4hoMepB00VImUookc'); 
  
// Database configuration  
define('DB_HOST', 'sql1.njit.edu'); 
define('DB_USERNAME', 'zaa4'); 
define('DB_PASSWORD', 'puerile89'); 
define('DB_NAME', 'zaa4');