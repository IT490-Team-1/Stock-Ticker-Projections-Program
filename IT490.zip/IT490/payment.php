<?php 
session_start();
// Include configuration file  
require_once 'config.php'; 

require "dbConnect.php";
 
// Get user ID from current SESSION 
//$userID = isset($_SESSION['loggedInUserID'])?$_SESSION['loggedInUserID']:1; 

if(isset($_SESSION['email'])){
    $session_email =$_SESSION['email'];
    $usertable = "SELECT * FROM usertable WHERE email = '$session_email'";
    $resul = mysqli_query($db, $usertable); 
    $ses_user = mysqli_fetch_assoc($resul);
}
 
$payment_id = $statusMsg = $api_error = ''; 
$ordStatus = 'error'; 
 
// Check whether stripe token is not empty 
if(!empty($_POST['subscr_plan']) && !empty($_POST['stripeToken'])){ 

    if(!isset($_SESSION["reg_email"]) && $_SESSION["reg_email"] == ""){
        header('location: signup-user.php');
                        exit();
    }



    

     
    // Retrieve stripe token and user info from the submitted form data 
    $token  = $_POST['stripeToken']; 
    $name = $_POST['name']; 
    $email = $_POST['email'];
    $code = 0; 
    $password = rand(999956565699999, 9999656565659999); 
    $encpass = password_hash($password, PASSWORD_BCRYPT);
     
    // Plan info 
    $planID = $_POST['subscr_plan']; 
    $planInfo = $plans[$planID]; 
    $planName = $planInfo['name']; 
    $planPrice = $planInfo['price']; 
    $planInterval = $planInfo['interval']; 


    // Include Stripe PHP library 
    require_once 'stripe-php/init.php'; 
     
    // Set API key 
    \Stripe\Stripe::setApiKey(STRIPE_API_KEY); 
     
    // Add customer to stripe 
    try {  
        $customer = \Stripe\Customer::create(array( 
            'email' => $email, 
            'source'  => $token 
        )); 
    }catch(Exception $e) {  
        $api_error = $e->getMessage();  
    } 
     
    if(empty($api_error) && $customer){  
     
        // Convert price to cents 
        $priceCents = round($planPrice*100); 
     
        // Create a plan 
        try { 
            $plan = \Stripe\Plan::create(array( 
                "product" => [ 
                    "name" => $planName 
                ], 
                "amount" => $priceCents, 
                "currency" => $currency, 
                "interval" => $planInterval, 
                "interval_count" => 1 
            )); 
        }catch(Exception $e) { 
            $api_error = $e->getMessage(); 
        } 
         
        if(empty($api_error) && $plan){ 
            // Creates a new subscription 
            try { 
                $subscription = \Stripe\Subscription::create(array( 
                    "customer" => $customer->id, 
                    "items" => array( 
                        array( 
                            "plan" => $plan->id, 
                        ), 
                    ), 
                )); 
            }catch(Exception $e) { 
                $api_error = $e->getMessage(); 
            } 
             
            if(empty($api_error) && $subscription){ 
                // Retrieve subscription data 
                $subsData = $subscription->jsonSerialize(); 
         
                // Check whether the subscription activation is successful 
                if($subsData['status'] == 'active'){ 


                    // Subscription info 
                    $subscrID = $subsData['id']; 
                    $custID = $subsData['customer']; 
                    $planID = $subsData['plan']['id']; 
                    $planAmount = ($subsData['plan']['amount']/100); 
                    $planCurrency = $subsData['plan']['currency']; 
                    $planinterval = $subsData['plan']['interval']; 
                    $planIntervalCount = $subsData['plan']['interval_count']; 
                    $created = date("Y-m-d H:i:s", $subsData['created']); 
                    $current_period_start = date("Y-m-d H:i:s", $subsData['current_period_start']); 
                    $current_period_end = date("Y-m-d H:i:s", $subsData['current_period_end']); 
                    $status = $subsData['status']; 



                    $subject = "Payment Successful";
                    $message = "Subscription Payment Successful";
                    $sender = "From: zaa4@njit.edu";
                   /* if(@mail($email, $subject, $message, $sender)){
                        $info = "Your Subscription $planinterval - $planAmount is Successful";
                   
                        exit();
                    }else{
                        echo $errors['otp-error'] = "Email not working on your server!";
                    }*/
                    $reg_name = $_SESSION["reg_name"];
                    $reg_email = $_SESSION["reg_email"];
                    $reg_encpass = $_SESSION["reg_encpass"];
                     
                    // Include database connection file 
                    $insert_data = "INSERT INTO usertable (name, email, password, code, status)
                        values('$reg_name', '$reg_email', '$reg_encpass', '0', 'verified')";
                    $data_check = mysqli_query($db, $insert_data);
                    $last_insert_id =  mysqli_insert_id($db);     

         
                    // Insert transaction data into the database 
                    $sql = "INSERT INTO user_subscriptions(user_id,stripe_subscription_id,stripe_customer_id,stripe_plan_id,plan_amount,plan_amount_currency,plan_interval,plan_interval_count,payer_email,created,plan_period_start,plan_period_end,status) VALUES('".$last_insert_id."','".$subscrID."','".$custID."','".$planID."','".$planAmount."','".$planCurrency."','".$planinterval."','".$planIntervalCount."','".$email."','".$created."','".$current_period_start."','".$current_period_end."','".$status."')"; 
                    $insert = $db->query($sql);  
                      
                    
                     
                    $ordStatus = 'success'; 
                    $statusMsg = 'Your Subscription Payment has been Successful!'; 
                    $mail_msg  =  '<div class="container">
                                        <div class="status">
                                            <h1>'.$statusMsg.'</h1>
                                                <h4>Payment Information</h4>
                                                <p><b>Reference Number:</b> '.$subscription_id.'</p>
                                                <p><b>Transaction ID:</b> '.$subscrID.'</p>
                                                <p><b>Amount:</b> '.$planAmount.' '.$planCurrency.'</p>
                                                
                                                <h4>Subscription Information</h4>
                                                <p><b>Plan Name:</b> '.$planName.'</p>
                                                <p><b>Amount:</b> '.$planPrice.' '.$currency.'</p>
                                                <p><b>Plan Interval:</b> '.$planInterval.'</p>
                                                <p><b>Period Start:</b> '.$current_period_start.'</p>
                                                <p><b>Period End:</b> '.$current_period_end.'</p>
                                                <p><b>Status:</b> '.$status.'</p>
                                                <h4>Payment Information</h4>
                                                <p><b>Your password:</b> '.$password.'</p>
                                        </div>
                                    </div>';
                    $to = $email;
                    $subject = 'Stock projection saas subscription';
                    $from = 'zaa4@njit.edu';
                     
                    // To send HTML mail, the Content-type header must be set
                    $headers  = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                     
                    // Create email headers
                    $headers .= 'From: '.$from."\r\n".
                        'Reply-To: '.$from."\r\n" .
                        'X-Mailer: PHP/' . phpversion();
                    $_SESSION['email'] = $_SESSION["reg_email"];
                    $_SESSION['password'] = $_SESSION["reg_password"];    

                    unset($_SESSION["reg_name"]);
                    unset($_SESSION["reg_email"]);
                    unset($_SESSION["reg_encpass"]);
                    unset($_SESSION["reg_code"]);
                    unset($_SESSION["reg_password"]);

                    if(mail($to, $subject, $mail_msg, $headers)){
                        
                        header('location: home.php');
                        exit();
                    } else{
                        echo 'Mail not configure.Please check you server email.';
                        header('location: home.php');
                        exit();

                    }    
                                                
                }else{ 
                  echo  $statusMsg = "Subscription activation failed!"; die;
                } 
            }else{ 
               echo $statusMsg = "Subscription creation failed! ".$api_error; die;
            } 
        }else{ 
            echo $statusMsg = "Plan creation failed! ".$api_error; die;
        } 
    }else{  
       echo $statusMsg = "Invalid card details! $api_error";  die;
    } 
}else{ 
   echo $statusMsg = "Error on form submission, please try again."; die;
} 
?>

