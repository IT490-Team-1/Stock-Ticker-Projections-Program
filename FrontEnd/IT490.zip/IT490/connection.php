<?php 
$con = mysqli_connect('sql1.njit.edu', 'zaa4', 'puerile89', 'zaa4');
?>