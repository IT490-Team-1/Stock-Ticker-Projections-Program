<?php

$myfile =  file_get_contents("output.txt");
//echo $myfile;
$array[] = explode(' ',$myfile);
//print_r($array);
if ($array[0][0] == "landingpage.php")  {
    include '/var/www/html/redirectlanding.php';
    //exit();
  } else if ($array[0][0] == "login.html") {
   // echo "success";
    include '/var/www/html/redirectlogin.php';
    //exit();
  } else if ($array[0][0] == "index.html") {
    include 'var/www/html/redirectindex.php';
    //exit();
  }
?>
