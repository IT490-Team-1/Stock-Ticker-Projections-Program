<?php
header("Location: login2.html");
exit;
?>
