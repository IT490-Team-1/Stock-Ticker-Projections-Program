<?php
header("Location: landingpage.php");
exit;
?>
