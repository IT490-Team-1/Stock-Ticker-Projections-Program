<!DOCTYPE html>
<html>
<body>
<link rel="stylesheet" href="style2.css">

<form id="container" action="sending2.php" method="post">
  <h1>IT 490 Stock Projection</h1>
  <fieldset id="inputs">
    <input type="text" name="ticker" id="ticker" placeholder="Stock Ticker" required autofocus />
    <label>Type of Data </label>

    <select name="data" id="data"> 
    <option>Linear-Regression</option>
    <option>Support-Vector-Machine-Regression</option>
    </select>
    
    
    
  </fieldset>
  
  
  <fieldset id="actions">
    <input type="submit" name="submit" id="submit" value="SUBMIT" />
    <a href="#">Log out</a>
  </fieldset>
</form>

</body>
</html>
