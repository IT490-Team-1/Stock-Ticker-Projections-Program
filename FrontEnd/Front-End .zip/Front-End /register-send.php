<?php

require_once __DIR__ . '/vendor/autoload.php';
set_include_path(".:/usr/share/php");
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$connection = new AMQPStreamConnection('25.84.3.30', 5672, 'zunair', 'zunair');
$channel = $connection->channel();

$channel->queue_declare('text1', false, false, false, false);

// if (isset($_POST['submit'])) {
echo "test";

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$password = $_POST['password'];
$code = "0";
$text = "hello";

$register = $_POST['Register'];
//$password = 'blah';
//$email = 'blah';
if ($register){



$msg = new AMQPMessage('Register' . ' ' .  $firstname . ' ' . $lastname . ' ' . $email . ' ' . $password . ' ' . $code . ' ' . $text);
$channel->basic_publish($msg, '', 'text1');
echo " [x] Sent Register" . $email . ',' . $password . "\n";

} else {

    $msg = new AMQPMessage('Register' . ' ' .  $firstname . ' ' . $lastname . ' ' . $email . ' ' . $password . ' ' . $code . ' ' . $text);


$channel->basic_publish($msg, '', 'text1');

echo " [x] Sent Register" . $email . ',' . $password . "\n";
}
exit;
// }
$channel->close();
$connection->close();
?>
