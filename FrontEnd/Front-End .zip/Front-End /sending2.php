<?php

require_once __DIR__ . '/vendor/autoload.php';
set_include_path(".:/usr/share/php");
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$connection = new AMQPStreamConnection('25.84.3.30', 5672, 'zunair', 'zunair');
$channel = $connection->channel();

$channel->queue_declare('text1', false, false, false, false);



$ticker = $_POST['ticker'];
$data = $_POST['data'];



//$password = 'blah';
//$email = 'blah';

if (isset($submit)){



$msg = new AMQPMessage('Ticker' . ' ' .  $ticker . ' ' . $data);
$channel->basic_publish($msg, '', 'text1');
echo " [x] Sent Ticker \n";

$myfile = file_get_contents('output.txt');
$array = explode(' ', $myfile);
if ($array[0] == 'Ticker') {
      $timestamp = $array[1];
      $tickername = $array[2];
      $confidence = $array[3];
      $dp1 = $array[5];
      $dp2 = $array[6];
      $dp3 = $array[7];
}
echo $timestamp . ',' . $tickername . ',' . $confidence . ',' . $dp1 . ',' .$dp1 . ',' . $dp2 . ',' . $dp3;

} else {

$msg = new AMQPMessage('Register Zunair Ahmed' . ' ' .  $ticker . ' ' . $data . ' 0' . ' Hello' );


$channel->basic_publish($msg, '', 'text1');

echo " [x] Sent Register" . $email . ',' . $password . "\n";
}

exit;
// }
$channel->close();
$connection->close();
?>
