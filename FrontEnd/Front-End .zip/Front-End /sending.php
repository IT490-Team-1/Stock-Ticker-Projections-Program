<?php

require_once __DIR__ . '/vendor/autoload.php';
set_include_path(".:/usr/share/php");
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$connection = new AMQPStreamConnection('25.84.3.30', 5672, 'zunair', 'zunair');
$channel = $connection->channel();

$channel->queue_declare('text1', false, false, false, false);

// if (isset($_POST['submit'])) {
// echo "test";

$ticker = $_POST['ticker'];
$data = $_POST['data'];


//$password = 'blah';
//$email = 'blah';

if (isset($submit)){



$msg = new AMQPMessage('Ticker' . ' ' .  $ticker . ' ' . $data);
$channel->basic_publish($msg, '', 'text1');
echo " [x] Sent Ticker \n";

} else {

$msg = new AMQPMessage('Register Zunair Ahmed' . ' ' .  $ticker . ' ' . $data . ' 0' . ' Hello' );


$channel->basic_publish($msg, '', 'text1');

echo " [x] Sent Register" . $email . ',' . $password . "\n";
}

exit;
// }
$channel->close();
$connection->close();
?>
