<?php

require_once __DIR__ . '/vendor/autoload.php';
set_include_path(".:/usr/share/php");
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$connection = new AMQPStreamConnection('25.84.3.30', 5672, 'zunair', 'zunair');
$channel = $connection->channel();

$channel->queue_declare('text1', false, false, false, false);

// if (isset($_POST['submit'])) {
echo "test";

$email = $_POST['email'];
$password = $_POST['password'];

$submit = $_POST['Login'];
$register = $_POST['Register'];
//$password = 'blah';
//$email = 'blah';


if (isset($submit)){
/*
if (empty($email)){
echo'error';
} else {
*/

$msg = new AMQPMessage('Login' . ' ' .  $email . ' ' . $password);
$channel->basic_publish($msg, '', 'text1');
echo " [x] Sent Login " . $email . ',' . $password . "\n";

} else { 

$msg = new AMQPMessage('Register Zunair Ahmed' . ' ' .  $email . ' ' . $password . ' 0' . ' Hello' );


$channel->basic_publish($msg, '', 'text1');

echo " [x] Sent Register " . $email . ',' . $password . "\n";
}

exit; 
// }
$channel->close();
$connection->close();

?>











