<?php

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;

$connection = new AMQPStreamConnection('25.84.3.30', 5672, 'zunair', 'zunair');
$channel = $connection->channel();

$channel->queue_declare('hello', false, false, false, false);

echo " [*] Waiting for messages. To exit press CTRL+C\n";

$callback = function ($msg) {
    echo ' [x] Received ', $msg->body, "\n";

    $table = $msg->body;
    $expand = $msg->body;

    echo $expand . " expand variable set \n";
    $array = explode(' ',$expand);
    echo $array[0] . " word recieved in array \n;";
 
    if ($array[0] == "Successfully-Registered"){
    	$myfile = fopen("output.txt","w");
	fwrite($myfile,"index.html");
	fclose($myfile);
    } elseif (($array[0] == "Failed-Registered") or ($array[0] == "Failure")) {
	$myfile = fopen("output.txt","w");
        fwrite($myfile,"login.html");
        fclose($myfile);
    } elseif ($array[0] == "Success"){
	$myfile = fopen("output.txt","w");
        fwrite($myfile,"landingpage.php");
        fclose($myfile);
    } elseif ($array[0]=="Ticker"){
	$myfile = fopen("output.txt", "w");
	fwrite($myfile,$array[1] . " ");
        fwrite($myfile,$array[2] . " ");
        fwrite($myfile,$array[3] . " ");
        fwrite($myfile,$array[4] . " ");
        fwrite($myfile,$array[5] . " ");
        fwrite($myfile,$array[6] . " ");
        fwrite($myfile,$array[7] . " ");
        fwrite($myfile,$array[8] . " ");

  }  
};

$channel->basic_consume('hello', '', false, true, false, false, $callback);

while ($channel->is_consuming()) {
    $channel->wait();
}

$channel->close();
$connection->close();
?>
